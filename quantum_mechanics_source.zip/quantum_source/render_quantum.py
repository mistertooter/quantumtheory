"""Render a 45-second educational animation. Requires numpy, Pillow, ffmpeg.
Run: python render_quantum.py. Output: quantum_mechanics.mp4.
Stylized analytic models, dimensionless units; not a microscope recording.
"""
import math, subprocess
from pathlib import Path
import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageFilter

W,H,FPS=900,1126,24
ROOT=Path(__file__).resolve().parent
FONT='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
BOLD='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
def font(n,b=False): return ImageFont.truetype(BOLD if b else FONT,n)
def text(d,xy,s,n=30,c='#d9e6fa',b=False): d.text(xy,s,font=font(n,b),fill=c)
def lines(d,y,items):
    for s in items: text(d,(52,y),s,29); y+=43
xx,yy=np.meshgrid(np.linspace(-4,4,400),np.linspace(-3,3,300))
r1=np.sqrt((xx+3)**2+(yy-.7)**2)
r2=np.sqrt((xx+3)**2+(yy+.7)**2)
amp1=1/np.sqrt(r1+.4);amp2=1/np.sqrt(r2+.4)
phase=12*(r1-r2)
intensity=(amp1**2+amp2**2+2*amp1*amp2*np.cos(phase))
intensity/=intensity.max()
rng=np.random.default_rng(42)
yd=np.linspace(-3,3,3000)
prob=np.cos(12*(np.sqrt(49+(yd-.7)**2)-np.sqrt(49+(yd+.7)**2))/2)**2*np.exp(-yd**2/5)
prob/=prob.sum()
hits=rng.choice(yd,4000,p=prob)
hitx=rng.uniform(90,635,4000)
stars=rng.uniform([30,170],[870,850],(100,2))

def frame(t):
    stage=min(int(t//15),2); u=t-stage*15
    im=Image.new('RGB',(W,H),'#050c1c');d=ImageDraw.Draw(im)
    for x,y in stars: d.ellipse((x,y,x+1,y+1),fill='#24344c')
    text(d,(50,30),'QUANTUM MECHANICS',39,'#ffffff',True)
    titles=['01  A particle has a wavefunction','02  Two paths can interfere','03  Measurement gives one result']
    text(d,(50,95),titles[stage],32,'#5ce8ff',True)
    d.rounded_rectangle((35,175,865,815),radius=24,outline='#314664',width=2)
    if stage==0:
        text(d,(65,200),'A FREE QUANTUM WAVE PACKET',24,'#b1c9ed',True)
        x=np.linspace(-5,5,750);tau=u*.07
        center=-2.4+4*tau; spread=tau/(2*.48**2); sigma=.48*np.sqrt(1+spread*spread)
        density=np.exp(-(x-center)**2/(2*sigma*sigma))/sigma*.48
        phase_packet=4*(x+2.4)-8*tau+(x-center)**2*spread/(4*.48**2*(1+spread*spread))-.5*np.arctan(spread)
        real=np.sqrt(density)*np.cos(phase_packet)
        pts=[(75+i,635-float(v)*220) for i,v in enumerate(density)]
        d.polygon([(75,635)]+pts+[(824,635)],fill='#123d70')
        d.line(pts,fill='#5ce8ff',width=5)
        d.line([(75+i,490-float(v)*95) for i,v in enumerate(real)],fill='#ff70dd',width=3)
        d.line((75,635,825,635),fill='#778ba8',width=2)
        text(d,(75,680),'Position x  →',27)
        text(d,(75,270),'Cyan: probability density |ψ|²',27,'#5ce8ff')
        text(d,(75,311),'Pink: real part of wavefunction ψ',27,'#ff70dd')
        text(d,(75,745),'The packet moves and spreads with time.',26)
        equation='iℏ ∂ψ/∂t = −(ℏ²/2m) ∂²ψ/∂x²'
        caption=['Schrödinger’s equation evolves the wavefunction.',
                 '|ψ|² gives position probabilities, not a solid cloud.',
                 'A wider packet has less precise position.']
    elif stage==1:
        text(d,(65,200),'DOUBLE-SLIT EXPERIMENT',26,'#b1c9ed',True)
        # Coherent outgoing spherical waves: hue shows phase; brightness shows intensity.
        field=amp1*np.exp(1j*(12*r1-u*5))+amp2*np.exp(1j*(12*r2-u*5))
        bright=np.clip(np.abs(field)/2,0,1)**.7
        angle=np.angle(field)
        arr=np.zeros((300,400,3),dtype=np.uint8)
        arr[:,:,0]=(bright*(120+115*np.sin(angle))).astype('uint8')
        arr[:,:,1]=(bright*(130+120*np.cos(angle))).astype('uint8')
        arr[:,:,2]=(bright*250).astype('uint8')
        im.paste(Image.fromarray(arr).resize((700,460)),(80,280));d=ImageDraw.Draw(im)
        # Mask upstream region, then animate incident plane waves.
        d.rectangle((80,280,165,740),fill='#071529')
        for k in range(6):
            x=80+((k*20+u*24)%85)
            d.line((x,285,x,735),fill='#37b9ed',width=2)
        for a,b in [(280,445),(465,552),(572,740)]:d.rectangle((163,a,179,b),fill='#bdc9db')
        d.rectangle((791,280,801,740),fill='#f7d68b')
        text(d,(90,755),'Slits',24);text(d,(620,755),'Detector screen',24)
        equation='P(x) = |ψ₁(x) + ψ₂(x)|²'
        caption=['With no path record, amplitudes add coherently.',
                 'Matching phases brighten; opposite phases cancel.',
                 'Color shows phase; brightness shows wave strength.']
    else:
        text(d,(65,200),'INDIVIDUAL HITS → INTERFERENCE',25,'#b1c9ed',True)
        n=int(4000*min(u/12,1)**1.5)
        glow=Image.new('RGB',(W,H));gd=ImageDraw.Draw(glow)
        for x,y in zip(hitx[:n],hits[:n]):
            py=490+y*68;gd.ellipse((x-2,py-2,x+2,py+2),fill='#53dcff')
        im=Image.blend(im,Image.new('RGB',(W,H),'#050c1c'),0)
        from PIL import ImageChops
        im=ImageChops.add(im,glow.filter(ImageFilter.GaussianBlur(5)))
        im=ImageChops.add(im,glow);d=ImageDraw.Draw(im)
        # Expected distribution alongside measured events.
        for j in range(400):
            y=-3+6*j/399
            p=math.cos(6*(math.sqrt(49+(y-.7)**2)-math.sqrt(49+(y+.7)**2)))**2*math.exp(-y*y/5)
            d.line((700,490+y*68,700+100*p,490+y*68),fill='#ffce69',width=2)
        text(d,(80,740),f'{n:,} detection events',28,'#5ce8ff',True)
        text(d,(657,225),'Expected',22,'#ffce69')
        text(d,(657,253),'probability',22,'#ffce69')
        equation='One hit is random. Many hits follow |ψ|².'
        caption=['Each detection is localized on the screen.',
                 'Repeated trials reveal the probability pattern.',
                 'Recording the path removes this interference.']
    d.rounded_rectangle((35,840,865,1055),radius=20,fill='#10213b')
    text(d,(52,858),equation,29,'#ffcf72',True)
    lines(d,914,caption)
    text(d,(40,1080),'Illustrative models • not to scale • time slowed',21,'#92a8c9')
    d.line((35,1068,35+830*t/45,1068),fill='#5ce8ff',width=4)
    return im

if __name__=='__main__':
    out=ROOT.parent/'quantum_mechanics.mp4'
    proc=subprocess.Popen(['ffmpeg','-y','-loglevel','error','-f','rawvideo','-vcodec','rawvideo','-pix_fmt','rgb24','-s',f'{W}x{H}','-r',str(FPS),'-i','-','-an','-c:v','libx264','-preset','fast','-crf','20','-pix_fmt','yuv420p','-movflags','+faststart',str(out)],stdin=subprocess.PIPE)
    for i in range(FPS*45):
        pic=frame(i/FPS)
        if i in [120,480,960]:pic.save(ROOT.parent/f'preview_{i}.jpg')
        proc.stdin.write(pic.tobytes())
        if i%240==0:print(f'{i//FPS}/45 seconds',flush=True)
    proc.stdin.close()
    if proc.wait():raise RuntimeError('ffmpeg failed')
    print(out)
