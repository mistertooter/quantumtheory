QUANTUM MECHANICS — 45-second captioned animation

Requirements: Python 3, numpy, Pillow, and ffmpeg on PATH.
Install Python dependencies: pip install numpy Pillow
Run: python render_quantum.py
The MP4 is written to the parent of this source folder.

00–15 seconds: A free Gaussian wave packet. Dimensionless hbar=m=1,
sigma0=0.48, mean momentum=4, and scaled animation time.
15–30 seconds: Coherent two-source outgoing-wave illustration of two slits.
30–45 seconds: Seeded random detection samples from an approximate
interference distribution with a Gaussian envelope.

These are teaching models, not a full numerical model of an apparatus.
The intensity models in scenes 2 and 3 are illustrative approximations;
they are not quantitative predictions for a specified real experiment.
Wavefunction colors encode phase, not the physical color of an electron.
Which-path information removes interference when it makes the path
states distinguishable, even when no person reads the path record.
The video has captions and no audio.
